const express = require('express');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const app = express();
const fetch = require('node-fetch'); // لإجراء طلبات HTTP من جهة الخادم
const { GoogleGenerativeAI } = require('@google/generative-ai'); // مكتبة Google Gemini API

// استخدام express.json() لتحليل الطلبات بصيغة JSON
app.use(express.json());
// لخدمة الملفات الثابتة (مثل ملف index.html و CSS و JS) من مجلد 'public'
app.use(express.static(path.join(__dirname, 'public')));

// تحديد مسارات مجلدات المواقع والمستخدمين
const SITES_DIR = path.join(__dirname, 'sites');
const USERS_DIR = path.join(__dirname, 'users');

// مفتاح API للذكاء الاصطناعي - **هام جدًا:** يجب استبدال هذا بمفتاحك الخاص.
// يفضل تخزينه كمتغير بيئة (Environment Variable) لزيادة الأمان في بيئة الإنتاج.
// المفتاح الموجود هنا هو مثال فقط وقد لا يكون صالحًا.
const GEMINI_API_KEY = 'AIzaSyA2uhLHqaJnX8LDjb7LRzAgqG1wphiJsBY';

// التأكد من وجود مجلد 'sites'، وإنشاءه إذا لم يكن موجوداً
if (!fs.existsSync(SITES_DIR)) {
    console.log(`Creating sites directory: ${SITES_DIR}`);
    fs.mkdirSync(SITES_DIR);
}

// التأكد من وجود مجلد 'users'، وإنشاءه إذا لم يكن موجوداً
if (!fs.existsSync(USERS_DIR)) {
    console.log(`Creating users directory: ${USERS_DIR}`);
    fs.mkdirSync(USERS_DIR);
}

// دالة مساعدة للتحقق من صحة الرابط المخصص (يمكن أن يحتوي على أحرف إنجليزية وأرقام وشرطة فقط)
function isValidCustomUrl(url) {
    return /^[a-zA-Z0-9-]+$/.test(url);
}

// --- نقطة نهاية لإنشاء حساب جديد ---
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    // التحقق من وجود اسم المستخدم وكلمة المرور
    if (!username || username.trim() === '' || !password || password.trim() === '') {
        return res.status(400).json({
            success: false,
            message: 'الرجاء إدخال اسم المستخدم وكلمة المرور.'
        });
    }

    const userFilePath = path.join(USERS_DIR, `${username.toLowerCase()}.json`);

    // التحقق مما إذا كان اسم المستخدم موجودًا بالفعل
    if (fs.existsSync(userFilePath)) {
        return res.status(409).json({
            success: false,
            message: 'اسم المستخدم هذا موجود بالفعل. الرجاء اختيار اسم آخر.'
        });
    }

    try {
        // توليد "salt" (قيمة عشوائية) وتشفير كلمة المرور
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // بيانات المستخدم لحفظها
        const userData = {
            username: username.toLowerCase(),
            password: hashedPassword,
            createdAt: new Date().toISOString()
        };
        // حفظ بيانات المستخدم في ملف JSON
        fs.writeFileSync(userFilePath, JSON.stringify(userData, null, 2));
        console.log(`User registered: ${username.toLowerCase()}`);
        res.json({
            success: true,
            message: 'تم إنشاء الحساب بنجاح. يمكنك الآن تسجيل الدخول.'
        });
    } catch (error) { 
        console.error('Error registering user:', error);
        res.status(500).json({
            success: false,
            message: 'حدث خطأ أثناء إنشاء الحساب.'
        });
    }
});

// --- نقطة نهاية لتسجيل الدخول ---
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // التحقق من وجود اسم المستخدم وكلمة المرور
    if (!username || username.trim() === '' || !password || password.trim() === '') {
        return res.status(400).json({
            success: false,
            message: 'الرجاء إدخال اسم المستخدم وكلمة المرور.'
        });
    }

    const userFilePath = path.join(USERS_DIR, `${username.toLowerCase()}.json`);

    // التحقق مما إذا كان اسم المستخدم موجودًا
    if (!fs.existsSync(userFilePath)) {
        return res.status(401).json({
            success: false,
            message: 'اسم المستخدم أو كلمة المرور غير صحيحة.'
        });
    }

    try {
        // قراءة بيانات المستخدم وفك تشفير كلمة المرور للمقارنة
        const userData = JSON.parse(fs.readFileSync(userFilePath));
        const isMatch = await bcrypt.compare(password, userData.password);

        if (isMatch) {
            console.log(`User logged in: ${userData.username}`);
            res.json({
                success: true,
                message: 'تم تسجيل الدخول بنجاح!',
                user: userData.username // إعادة اسم المستخدم لتحديد الجلسة في الواجهة الأمامية
            });
        } else { 
            res.status(401).json({
                success: false,
                message: 'اسم المستخدم أو كلمة المرور غير صحيحة.'
            });
        }
    } catch (error) { 
        console.error('Error logging in user:', error);
        res.status(500).json({
            success: false,
            message: 'حدث خطأ أثناء تسجيل الدخول.'
        });
    }
});

// --- نقطة نهاية لحفظ الموقع ---
app.post('/save-site', (req, res) => {
    const { id, name, customUrl, html, user } = req.body;

    // التحقق من المدخلات الأساسية
    if (!name || name.trim() === '') {
        return res.status(400).json({
            success: false,
            message: 'اسم الموقع مطلوب.'
        });
    }
    if (!html || html.trim() === '') {
        return res.status(400).json({
            success: false,
            message: 'كود HTML لا يمكن أن يكون فارغاً.'
        });
    }
    if (!user || user.trim() === '') {
        return res.status(401).json({
            success: false,
            message: 'غير مصرح لك. الرجاء تسجيل الدخول.'
        });
    }

    let finalCustomUrl = customUrl ? customUrl.trim() : null;

    // التحقق من صحة الرابط المخصص إذا تم تقديمه
    if (finalCustomUrl) {
        if (!isValidCustomUrl(finalCustomUrl)) {
            return res.status(400).json({
                success: false,
                message: 'يمكن استخدام الأحرف الإنجليزية والأرقام والشرطة فقط في الرابط المخصص.'
            });
        }
        const customUrlHtmlPath = path.join(SITES_DIR, `${finalCustomUrl}.html`);
        // التحقق مما إذا كان الرابط المخصص مستخدمًا بالفعل من قبل موقع آخر
        if (fs.existsSync(customUrlHtmlPath)) {
            let existingSiteData = null;
            try {
                // البحث عن ملف JSON المرتبط بالرابط المخصص للتحقق من المالك
                const siteFiles = fs.readdirSync(SITES_DIR);
                const jsonFile = siteFiles.find(f => f.endsWith('.json') && JSON.parse(fs.readFileSync(path.join(SITES_DIR, f))).customUrl === finalCustomUrl);
                if (jsonFile) {
                    existingSiteData = JSON.parse(fs.readFileSync(path.join(SITES_DIR, jsonFile)));
                }
            } catch (error) { 
                console.error('Error checking existing custom URL for conflict:', error);
            }

            // إذا كان الرابط المخصص مستخدمًا من قبل موقع آخر (ليس الموقع الذي يتم حفظه الآن)
            if (!existingSiteData || existingSiteData.id !== id) {
                return res.status(400).json({
                    success: false,
                    message: 'هذا الرابط المخصص مستخدم بالفعل من قبل موقع آخر.'
                });
            }
        }
    }

    // بناء كائن بيانات الموقع
    const siteData = {
        id,
        name: name.trim(),
        customUrl: finalCustomUrl,
        html: html.trim(),
        user: user.trim(),
        createdAt: new Date().toISOString()
    };
    const siteJsonPath = path.join(SITES_DIR, `${id}.json`);
    const siteHtmlPath = path.join(SITES_DIR, `${id}.html`);
    try {
        // إذا كان الموقع موجودًا، تحقق من تغيير الرابط المخصص القديم وحذفه
        if (fs.existsSync(siteJsonPath)) {
            const oldSiteData = JSON.parse(fs.readFileSync(siteJsonPath));
            if (oldSiteData.customUrl && oldSiteData.customUrl !== finalCustomUrl) {
                const oldCustomHtmlPath = path.join(SITES_DIR, `${oldSiteData.customUrl}.html`);
                if (fs.existsSync(oldCustomHtmlPath)) {
                    fs.unlinkSync(oldCustomHtmlPath);
                    console.log(`Deleted old custom URL HTML: ${oldCustomHtmlPath}`);
                }
            }
        }

        // حفظ بيانات الموقع في ملف JSON و HTML
        fs.writeFileSync(siteJsonPath, JSON.stringify(siteData, null, 2));
        fs.writeFileSync(siteHtmlPath, html);
        console.log(`Site saved: ${id}.json and ${id}.html`);

        // إذا كان هناك رابط مخصص، قم بإنشاء ملف HTML باسم الرابط المخصص أيضاً
        if (finalCustomUrl) {
            const customHtmlPath = path.join(SITES_DIR, `${finalCustomUrl}.html`);
            fs.writeFileSync(customHtmlPath, html);
            console.log(`Custom URL HTML saved: ${finalCustomUrl}.html`);
        }

        res.json({
            success: true,
            siteId: id,
            message: 'تم حفظ الموقع بنجاح'
        });
    } catch (error) { 
        console.error('Error saving site:', error);
        res.status(500).json({
            success: false,
            message: 'حدث خطأ داخلي أثناء حفظ الموقع.'
        });
    }
});

// --- نقطة نهاية لجلب كل مواقع المستخدم ---
app.get('/get-sites', (req, res) => {
    const user = req.query.user;
    const sites = [];

    if (!user) {
        return res.status(400).json({
            success: false,
            message: 'اسم المستخدم مطلوب.'
        });
    }

    if (!fs.existsSync(SITES_DIR)) {
        return res.json([]); // إذا لم يكن مجلد المواقع موجوداً، لا توجد مواقع
    }

    // قراءة جميع ملفات JSON في مجلد المواقع
    fs.readdirSync(SITES_DIR).forEach(file => {
        if (file.endsWith('.json')) {
            try {
                const siteData = JSON.parse(fs.readFileSync(path.join(SITES_DIR, file)));
                // إضافة المواقع التي يمتلكها المستخدم فقط
                if (siteData.user === user) {
                    sites.push(siteData);
                }
            } catch (error) {
                console.error(`Error reading or parsing site file: ${file}`, error);
            }
        }
    });

    // ترتيب المواقع حسب تاريخ الإنشاء الأحدث أولاً
    sites.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(sites);
});

// --- نقطة نهاية لجلب موقع معين بواسطة معرفه ---
app.get('/get-site/:id', (req, res) => {
    const siteId = req.params.id;
    const siteJsonPath = path.join(SITES_DIR, `${siteId}.json`);

    if (fs.existsSync(siteJsonPath)) {
        try {
            const siteData = JSON.parse(fs.readFileSync(siteJsonPath));
            res.json(siteData);
        } catch (error) { 
            console.error(`Error parsing site JSON for ID ${siteId}:`, error);
            res.status(500).json({
                error: 'حدث خطأ أثناء قراءة بيانات الموقع.'
            });
        }
    } else {
        res.status(404).json({
            error: 'الموقع غير موجود'
        });
    }
});
// --- نقطة نهاية لعرض الموقع للعامة (بواسطة ID أو Custom URL) ---
app.get('/site/:idOrCustomUrl', (req, res) => {
    const idOrCustomUrl = req.params.idOrCustomUrl;
    let filePath = path.join(SITES_DIR, `${idOrCustomUrl}.html`); // محاولة البحث بالـ ID أولاً

    // إذا لم يتم العثور على الملف بالـ ID، حاول البحث عن طريق customUrl
    if (!fs.existsSync(filePath)) {
        const siteFiles = fs.readdirSync(SITES_DIR);
        let foundSite = null;
        for (const file of siteFiles) {
            if (file.endsWith('.json')) {
                try {
                    const siteData = JSON.parse(fs.readFileSync(path.join(SITES_DIR, file)));
                    if (siteData.customUrl === idOrCustomUrl) {
                        foundSite = siteData;
                        // استخدم الـ ID الأصلي للموقع لعرض ملف HTML
                        filePath = path.join(SITES_DIR, `${siteData.id}.html`);
                        break;
                    }
                } catch (error) { 
                    console.error(`Error reading site file for custom URL check: ${file}`, error);
                }
            }
        }
    }

    // إذا تم العثور على الملف، ارسله للمتصفح
    if (fs.existsSync(filePath)) {
        res.sendFile(filePath);
    } else { 
        // إذا لم يتم العثور على الموقع، أرسل صفحة خطأ 404
        res.status(404).send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>الموقع غير موجود</title>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body {
                        font-family: 'Tajawal', sans-serif;
                        text-align: center;
                        padding: 50px;
                        background: #f5f7fa;
                        color: #333;
                    }
                    h1 { color: #6C5CE7; margin-bottom: 20px;}
                    p { color: #636E72; font-size: 1.1em;}
                </style>
            </head>
            <body>
                <h1>الموقع غير موجود</h1>
                <p>قد يكون الرابط خاطئاً أو تم حذف الموقع.</p>
            </body>
            </html>
        `);
    }
});

// --- نقطة نهاية لمعاينة الموقع داخل لوحة التحكم (بواسطة ID) ---
app.get('/site-preview/:id', (req, res) => {
    const id = req.params.id;
    const siteJsonPath = path.join(SITES_DIR, `${id}.json`);

    if (fs.existsSync(siteJsonPath)) {
        try {
            const siteData = JSON.parse(fs.readFileSync(siteJsonPath));
            // إرسال كود HTML مباشرة للمعاينه
            res.send(siteData.html);
        } catch (error) {
            console.error(`Error parsing site JSON for preview ID ${id}:`, error);
            res.status(500).send('حدث خطأ أثناء تحميل المعاينة.');
        }
    } else {
        res.status(404).send('الموقع غير موجود للمعاينه');
    }
});
// --- نقطة نهاية لحذف موقع ---
app.delete('/delete-site/:id', (req, res) => {
    const siteId = req.params.id;
    const siteJsonPath = path.join(SITES_DIR, `${siteId}.json`);
    const siteHtmlPath = path.join(SITES_DIR, `${siteId}.html`);

    if (fs.existsSync(siteJsonPath)) {
        try {
            const siteData = JSON.parse(fs.readFileSync(siteJsonPath));

            // حذف ملف JSON للموقع
            fs.unlinkSync(siteJsonPath);
            console.log(`Deleted site JSON: ${siteJsonPath}`);

            // حذف ملف HTML للموقع
            if (fs.existsSync(siteHtmlPath)) {
                fs.unlinkSync(siteHtmlPath);
                console.log(`Deleted site HTML: ${siteHtmlPath}`);
            }
            // إذا كان للموقع رابط مخصص، احذف ملف HTML الخاص به أيضاً
            if (siteData.customUrl) {
                const customHtmlPath = path.join(SITES_DIR, `${siteData.customUrl}.html`);
                if (fs.existsSync(customHtmlPath)) {
                    fs.unlinkSync(customHtmlPath);
                    console.log(`Deleted custom URL HTML: ${customHtmlPath}`);
                }
            }
            res.json({
                success: true,
                message: 'تم حذف الموقع بنجاح'
            });
        } catch (error) { 
            console.error(`Error deleting site files for ID ${siteId}:`, error);
            res.status(500).json({
                success: false,
                error: 'حدث خطأ أثناء حذف الموقع'
            });
        }
    } else { 
        res.status(404).json({
            success: false,
            error: 'الموقع غير موجود للحذف'
        });
    }
});

// --- نقطة نهاية لتوليد كود HTML باستخدام الذكاء الاصطناعي (Google Gemini) ---
app.post('/generate-ai-html', async (req, res) => { // تم تغيير المسار هنا
    const { prompt } = req.body;

    if (!prompt || prompt.trim() === '') {
        return res.status(400).json({
            success: false,
            message: 'الرجاء إدخال وصف لتوليد كود HTML.'
        });
    }

    try {
        // تهيئة نموذج Gemini AI بمفتاح API
        const genAI = new GoogleGenerativeAI(GEMINI_API_KEY); // استخدم مفتاح الـ API من المتغير
        // استخدام نموذج gemini-2.0-flash لسرعته وكفاءته
        const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

        // بناء الـ prompt لضمان الحصول على كود HTML كامل وصالح
        const fullPrompt = `أنت مطور ويب خبير. قم بتوليد كود HTML5 كاملاً وصالحاً لصفحة ويب استناداً إلى الوصف التالي: "${prompt}".
        تأكد أن الكود يتضمن:
        1.  <!DOCTYPE html>
        2.  <html lang="ar" dir="rtl">
        3.  <head> (مع charset, viewport, و <title> مناسب)
        4.  <body>
        5.  إذا كان الوصف يتطلب أي تنسيقات CSS، قم بتضمينها داخل وسم <style> في الـ <head>.
        6.  لا تضع أي كود JavaScript إلا إذا طُلب ذلك بوضوح في الوصف.
        7.  الهدف هو الحصول على صفحة ويب جاهزة للاستخدام مباشرة.
        **ملاحظة هامة**: يرجى إرجاع كود HTML فقط، بدون أي نص إضافي أو مقدمات أو خاتمات أو أكواد Markdown مثل \`\`\`html أو \`\`\`. فقط الكود النظيف.`;


        const result = await model.generateContent(fullPrompt);
        const responseText = result.response.text();

        // قم بمعالجة النص الذي تم إرجاعه من Gemini لإزالة أي أكواد Markdown (مثل ```html)
        let generatedHtml = responseText;
        if (generatedHtml.startsWith('```html')) {
            generatedHtml = generatedHtml.substring(7); // إزالة ```html
        }
        if (generatedHtml.endsWith('```')) {
            generatedHtml = generatedHtml.substring(0, generatedHtml.length - 3); // إزالة ```
        }
        generatedHtml = generatedHtml.trim(); // إزالة أي مسافات بيضاء إضافية

        res.status(200).json({
            success: true,
            html_code: generatedHtml
        });

    } catch (error) { 
        console.error('Error calling Gemini API:', error); // هذا قد يظهر لك شيئًا الآن
        let detailedErrorMessage = 'حدث خطأ غير متوقع أثناء الاتصال بخدمة الذكاء الاصطناعي.';
        if (error.message) { 
            detailedErrorMessage = `خطأ في الاتصال: ${error.message}. تأكد من صحة مفتاح API ووصول الخادم للإنترنت.`;
        }
        res.status(500).json({
            success: false,
            message: detailedErrorMessage
        });
    }
});

// تحديد المنفذ الذي سيستمع عليه الخادم
const PORT = process.env.PORT || 25594;
app.listen(PORT, () => {
    console.log(`Server online on port ${PORT}`);
});
